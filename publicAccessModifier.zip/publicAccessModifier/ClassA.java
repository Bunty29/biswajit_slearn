package publicAccessModifier;



public class ClassA {
	
		void display() // default access modifier
		{
		System.out.println("'CLassA' is shown in public access modifier ");
		}
	}
class main
{
	public static void main(String[] args)
	{
		ClassA obj = new ClassA();
		obj.display();
		
}}
